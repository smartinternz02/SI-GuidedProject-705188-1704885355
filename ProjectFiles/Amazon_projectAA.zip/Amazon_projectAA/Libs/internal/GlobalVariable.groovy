package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object inputString
     
    /**
     * <p></p>
     */
    public static Object PhoneNo
     
    /**
     * <p></p>
     */
    public static Object Password
     
    /**
     * <p></p>
     */
    public static Object PinCode
     
    /**
     * <p></p>
     */
    public static Object inputSearch
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            inputString = selectedVariables['inputString']
            PhoneNo = selectedVariables['PhoneNo']
            Password = selectedVariables['Password']
            PinCode = selectedVariables['PinCode']
            inputSearch = selectedVariables['inputSearch']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
