<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Your Orders</name>
   <tag></tag>
   <elementGuidId>be7c87d8-ecf3-4dab-8808-cf4ed180bdec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div/div/div[2]/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.a-spacing-none.ya-card__heading--rich.a-text-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>3f54a0f5-3752-43ee-921d-694e95d648d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none ya-card__heading--rich a-text-normal</value>
      <webElementGuid>b2fcadba-e7e4-4668-a1b9-21b43333844d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Your Orders
                </value>
      <webElementGuid>fe1add0a-1cfd-411f-93bc-9de68a32f4dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span9 a-span-last&quot;]/h2[@class=&quot;a-spacing-none ya-card__heading--rich a-text-normal&quot;]</value>
      <webElementGuid>7c8fd497-96be-4df8-bd39-588aa06375a4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div/div/div[2]/h2</value>
      <webElementGuid>ea5a8df5-6643-471f-8571-abf04ad6d1f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>cb6cc77c-99c3-4025-935a-605f06b4a24e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
                    Your Orders
                ' or . = '
                    Your Orders
                ')]</value>
      <webElementGuid>4aaad0f2-abbb-45f1-9272-f1edd64f4db0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
