<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Your Orders</name>
   <tag></tag>
   <elementGuidId>d5f6dbf4-d92b-4fe1-be09-0c441ed8502e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div/div/div[2]/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.a-spacing-none.ya-card__heading--rich.a-text-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>6d28bd09-21ac-4c34-99b1-c49e47144386</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none ya-card__heading--rich a-text-normal</value>
      <webElementGuid>7e798af4-16f5-4456-a6cb-e11e404d84bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Your Orders
                </value>
      <webElementGuid>cd94a5be-5dbf-4776-975f-ccaee8869198</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span9 a-span-last&quot;]/h2[@class=&quot;a-spacing-none ya-card__heading--rich a-text-normal&quot;]</value>
      <webElementGuid>195a5c6f-8224-4bde-95e0-2a618c4b1795</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div/div/div[2]/h2</value>
      <webElementGuid>f14b5666-1ec7-4476-b36a-4caf3a842f11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>f57ef635-740a-4cb1-a344-fc3a5f38ec67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
                    Your Orders
                ' or . = '
                    Your Orders
                ')]</value>
      <webElementGuid>cc75f01e-7f20-40da-a483-622c4da70943</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
