<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_testcase_001_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>d3f90133-69bf-43c3-893d-4c2b7c8c15a9</testSuiteGuid>
   <testCaseLink>
      <guid>de1b3dcd-7fcb-4788-95b4-6de8a11b97ac</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon_testcase_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>74e15893-c08a-420e-8101-dd1619516fd4</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_001</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>74e15893-c08a-420e-8101-dd1619516fd4</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>inputSearch</value>
         <variableId>24e10c90-7416-4fa0-900a-f038fd0a17f1</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
