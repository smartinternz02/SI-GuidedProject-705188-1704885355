<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_testcase_003_Excel</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c4130c23-9127-43bd-8d5a-2420683c23cc</testSuiteGuid>
   <testCaseLink>
      <guid>608f9c29-81ac-467a-8fae-09069626e169</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon_testcase_003</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>3630c8bc-0764-4bab-adaf-b47b66e9cd4e</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_003</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>3630c8bc-0764-4bab-adaf-b47b66e9cd4e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>PhoneNo</value>
         <variableId>eb80211c-9d22-40bc-a139-2901a8838c38</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
